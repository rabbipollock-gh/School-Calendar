# Handoff: School Hours — Structured Settings Editor + PDF Layout

## Overview
This handoff covers two changes to the YAYOE Calendar app:

1. **Settings panel** — replace the single freeform "School Hours" textarea with a structured, row-based editor so the user can add/remove/reorder schedule entries, attach a small "note" to any row (e.g. "All Grades", "Boys 3–8"), and edit a separate bold footnote.
2. **PDF "School Information" card** — redesign the "School Hours" block at the bottom of the card to render those structured rows as **color-coded pills** (one per row) so the layout stays compact and legible even with 5+ schedule lines.

## Scope: Which PDF Templates

This change targets the **landscape PDF exports only**, specifically:

- **Traditional — landscape**
- **Classic — landscape**

These are the two layouts where the bottom-right "School Information" card lives (matching the screenshot the user provided). If portrait or other templates render their own school-info card, leave them alone for this pass — the user will call those out separately if/when they need the same treatment.

The underlying data model (`schoolHours: { rows, footnote }`) is shared across all templates, so changing it once in settings flows through to whichever templates read it. Only the **render code in the Traditional/Classic landscape templates** needs the new pill layout.

The goal: the existing freeform textarea can't fit the full schedule (Preschool, Yesod–4th, 5th–8th, Friday, Sunday + a Kodesh note) without wrapping or running off the box. Structured input + pill-based render fixes both ends.

## About the Design Files
The HTML file in this bundle (`School Hours Box.html`) is a **design reference** — a clickable mockup showing the intended look. It is **not production code to ship**. The job is to **recreate the design in the YAYOE Calendar codebase** using its existing stack (React + whatever PDF library it uses today — likely `@react-pdf/renderer`, `pdfmake`, or `jsPDF`/`html2canvas`).

The mockup contains several layout explorations. **The final direction is `C2` ("Color pills") for the PDF render**, and the **"Settings Backend — Structured Input"** section for the editor. Other variants (A, B, D, D2, E, F) are kept for reference only.

## Fidelity
**High-fidelity.** All colors, spacing, typography, and component states are specified below with exact values. Recreate pixel-perfectly using the codebase's existing component/styling patterns.

---

## Data Model

Replace the current `schoolHours: string` field on the school-info settings object with:

```ts
type PillColor = "navy" | "green" | "blue" | "gold" | "purple";

interface SchoolHoursRow {
  id: string;          // uuid, for stable list keys + DnD
  color: PillColor;    // pill background
  label: string;       // e.g. "Preschool", "Yesod – 4th", "Friday"
  time: string;        // e.g. "8:15 AM – 3:30 PM"
  note: string;        // optional small text after time, e.g. "All Grades", "Boys 3–8"
}

interface SchoolHours {
  rows: SchoolHoursRow[];
  footnote: string;    // bold note rendered below the list, e.g. "No Preschool on Kodesh Only Days"
}
```

### Default seed (for new installs and migration)

```js
{
  rows: [
    { id: <uuid>, color: "green",  label: "Preschool",   time: "8:15 AM – 3:30 PM",  note: "" },
    { id: <uuid>, color: "navy",   label: "Yesod – 4th", time: "8:15 AM – 3:45 PM",  note: "" },
    { id: <uuid>, color: "blue",   label: "5th – 8th",   time: "8:15 AM – 4:30 PM",  note: "" },
    { id: <uuid>, color: "gold",   label: "Friday",      time: "8:15 AM – 1:00 PM",  note: "All Grades" },
    { id: <uuid>, color: "purple", label: "Sunday",      time: "9:00 AM – 12:00 PM", note: "Boys 3–8" },
  ],
  footnote: "No Preschool on Kodesh Only Days"
}
```

### Migration from existing freeform string

If users have an existing `schoolHours` string saved, parse it line by line:
- Split each non-empty line on the **first colon**.
- Strip leading/trailing `**` markdown bold markers from the label half.
- Left of colon → `label`; right of colon (trimmed) → `time`.
- `note` defaults to `""`, `color` defaults to `"navy"`.
- `footnote` defaults to `""` (let the user opt in).

User can re-pick colors and split out notes after migration.

---

## Screen 1: Settings Panel — Hours Editor

### Location
Inside the existing **Settings → School Information** section, replacing the current `School Hours` textarea (the one boxed in blue in the screenshot the user provided).

### Layout
- Section eyebrow: `SCHOOL HOURS` — `11px` `700` weight, letter-spacing `0.14em`, color `#8ea0c5`.
- Help text below eyebrow: `12px`, color `#6b7ba0`. Copy:
  > Add a row per schedule. The `Note` column shows as small gray text after the time. Reorder by dragging the grip.
  (Wrap `Note` in an inline code chip: bg `#1c2848`, color `#cfd5e6`, padding `1px 6px`, radius `4px`.)
- Editor container: bg `#0a1226`, border `1px solid #1c2848`, radius `10px`, padding `12px`.

### Hours Editor (row container)

**Column headers** (above the rows):
- Grid: `16px 24px 1fr 1fr 1fr 24px`, column-gap `8px`.
- Cells: empty · `Color` · `Label` · `Time` · `Note` · empty.
- Style: `10px` `700`, letter-spacing `0.1em`, uppercase, color `#4a5778`.

**Each row** uses the same grid:
| Column | Content | Notes |
|---|---|---|
| 1 (`16px`) | `⋮⋮` grip handle | `#4a5778`, cursor `grab` |
| 2 (`24px`) | Color swatch (`22×22` square, radius `6px`, border `1px rgba(255,255,255,0.1)`) | Clicking opens a popover with the 5 palette colors |
| 3 (`1fr`) | Label `<input type="text">` | Placeholder: empty |
| 4 (`1fr`) | Time `<input type="text">` | Placeholder: empty |
| 5 (`1fr`) | Note `<input type="text">` | Placeholder: `optional` |
| 6 (`24px`) | `✕` delete button | `#4a5778`, hover `#d6584b` |

Input styling (all three text inputs):
- bg `#0a1226`, border `1px solid #1c2848`, radius `6px`, padding `7px 9px`, font-size `13px`, color `#e8ecf4`.
- Focus: `outline: none; border-color: #4a78d3;`
- Placeholder color: `#4a5778`.

Row divider: `1px dashed #1c2848` between rows. Last row no divider.

**Add row button** (below the rows):
- Full width, padding `9px 12px`, border `1px dashed #2c3d6a`, radius `8px`.
- bg transparent, color `#8ea0c5`, font-size `13px`, `500` weight.
- Centered with a `+` glyph: `+  Add hours row`.
- Hover: border `#4a78d3`, color `#cfd5e6`.
- onClick: append `{ id: uuid, color: "navy", label: "", time: "", note: "" }`.

### Footnote field (separate block, below the editor)

- Label: `Footnote` followed by a small `(rendered bold in PDF)` hint in `#6b7ba0`, `12px`.
- Input: full-width text input. bg `#0a1226`, border `1px solid #1c2848`, radius `8px`, padding `10px 12px`, font-size `14px`.
- Helper text below: `11px`, `#6b7ba0`. Copy:
  > Shown below the hours list with a star ★ and divider line. Leave blank to hide.

### Color picker popover

Triggered by clicking a row's color swatch. 5 swatches in a row, each `22×22`:

| Name | Hex |
|---|---|
| navy | `#142a5c` |
| green | `#1a8a6a` |
| blue | `#1f6dbf` |
| gold | `#d98b1a` |
| purple | `#7c4ca8` |

Selecting one updates the row's `color` and closes the popover.

### Drag-to-reorder

Use any DnD library the codebase already includes (e.g. `dnd-kit/sortable`, `react-beautiful-dnd`). If none, prefer `@dnd-kit/sortable`. Grip handle (`⋮⋮`) is the drag handle; rows reorder vertically only.

### State persistence

Save `schoolHours` (the new object) wherever the existing settings are persisted (probably localStorage). On load, hydrate from storage; if absent, use the default seed above.

---

## Screen 2: PDF "School Information" Card — School Hours Block

### Location
The bottom-right card on the **Traditional landscape** and **Classic landscape** PDF templates. Replace only the **"SCHOOL HOURS"** block at the bottom of that card. The header (school crest + name) and the colored-square legend grid above it stay unchanged.

> **Important:** Only edit the render code for these two templates. Other templates (portrait variants, etc.) are out of scope for this pass even though they share the same `schoolHours` data — they'll keep rendering with their current code paths until the user asks for the same treatment there.

### Container
- Outer panel (the soft blue rectangle): bg `#eef3f9`, radius `10px`, padding `14px 16px 12px`, margin `8px 16px 18px` (or whatever matches the existing card).
- Eyebrow: `SCHOOL HOURS` — `11px` `700`, letter-spacing `0.1em`, color `#142a5c`, margin `0 0 8px`.

### Rows

Render each `row` in `schoolHours.rows` (in order) as a single grid line:

- Grid: `140px 1fr`, column-gap `12px`, align-items `center`, padding `3px 0`.
- **Left cell — Pill:**
  - Inline-flex, centered, padding `5px 10px`, radius `999px` (fully rounded), text-align center, line-height `1`.
  - Background: the row's `color` from the palette table above.
  - Color: `#ffffff`.
  - Font: `11px`, `700`, letter-spacing `0.05em`, uppercase.
  - Content: `row.label`.
- **Right cell — Value:**
  - Font: `13.5px`, `500`, color `#1b2440`, `font-variant-numeric: tabular-nums` (so times align across rows).
  - Content: `row.time`, then if `row.note` non-empty, append a space and a `<span class="meta">{row.note}</span>` styled:
    - `font-size: 11px`, `font-weight: 600`, color `#5a6588`, letter-spacing `0.02em`, `margin-left: 8px`, vertical-align `1px`. **No background, no border, no uppercase.**

Row gap: `6px` between rows (use flex/gap, not margin).

### Footnote

If `schoolHours.footnote` is non-empty:

- Container: margin-top `10px`, padding-top `9px`, border-top `1px solid #d6dde9`.
- Text: `12.5px`, `700` weight, color `#142a5c`, text-align center.
- Prefix with a `★` glyph in `#d98b1a`, margin-right `4px`.

If empty, render nothing (no divider, no whitespace).

### Underline (existing decorative element)

Keep the existing gold underline at the bottom of the panel: `90%` width, `2px` tall, bg `#d98b1a`, radius `2px`, centered, margin-top `12px`.

### Wrapping / overflow

Pill column is fixed `140px`. If a label is longer than fits, allow the pill to grow with `min-width: 0` on the cell and let the time wrap to the next line below the pill (rare). Keep `white-space: nowrap` off on the value so notes can wrap if needed.

---

## Design Tokens

### Colors

| Token | Hex | Used for |
|---|---|---|
| `--ink-900` | `#142a5c` | Navy (header bg, primary text, default pill) |
| `--ink-700` | `#1b2440` | Body text |
| `--ink-500` | `#5a6588` | Muted text, notes |
| `--ink-300` | `#cfd5e6` | Subtitle text on dark header |
| `--bg-page` | `#eef1f6` | Page bg around the card |
| `--bg-panel-soft` | `#eef3f9` | Hours panel bg |
| `--card-bg` | `#ffffff` | Card bg |
| `--card-border` | `#e3e7ef` | Card border |
| `--divider` | `#d6dde9` | Inner dividers |
| `--accent-gold` | `#d98b1a` | Underline, ★ accent, gold pill |
| `--pill-green` | `#1a8a6a` | Preschool pill |
| `--pill-navy` | `#142a5c` | Default pill |
| `--pill-blue` | `#1f6dbf` | "Older grades" pill |
| `--pill-purple` | `#7c4ca8` | Sunday pill |
| `--legend-red` | `#d6584b` | No School (legend, unchanged) |
| `--legend-org` | `#d98b1a` | Early Dismissal (legend, unchanged) |
| `--legend-pur` | `#7c4ca8` | Staff (legend, unchanged) |
| `--legend-blu` | `#1f6dbf` | School Event (legend, unchanged) |
| `--legend-gld` | `#b88a14` | Chanukah 3:45 (legend, unchanged) |
| `--legend-grn` | `#1a8a6a` | Hebrew Only (legend, unchanged) |

### Settings panel (dark) tokens

| Token | Hex |
|---|---|
| `--s-bg` | `#0e1a33` |
| `--s-head` | `#1c3260` |
| `--s-input-bg` | `#0a1226` |
| `--s-input-border` | `#1c2848` |
| `--s-input-focus` | `#4a78d3` |
| `--s-text` | `#e8ecf4` |
| `--s-text-muted` | `#8ea0c5` |
| `--s-text-faint` | `#6b7ba0` |
| `--s-text-placeholder` | `#4a5778` |

### Typography

- Font family: `Inter, system-ui, sans-serif` (matches existing app).
- Use `font-variant-numeric: tabular-nums` on all time values so they align column-wise.
- Sizes used:
  - Eyebrow: `11px` / `700` / `0.1em` tracking / uppercase
  - Row label (pill): `11px` / `700` / `0.05em` tracking / uppercase
  - Row time value: `13.5px` / `500`
  - Row note (meta): `11px` / `600`
  - Footnote: `12.5px` / `700`
  - Settings input: `13–14px` / `400`

### Spacing

- Card outer padding: keep existing.
- Hours panel inner padding: `14px 16px 12px`.
- Row gap (between pill rows): `6px`.
- Footnote spacing: `10px` top margin, `9px` top padding (above divider).

### Border radius

- Card: `14px`
- Hours panel: `10px`
- Settings editor container: `10px`
- Inputs: `6–8px`
- Pills: `999px` (fully rounded)
- Color swatch: `6px`

---

## Interactions & Behavior

### Settings Editor

| Action | Behavior |
|---|---|
| Type in any input | Updates the corresponding field on that row; persist on blur or debounced. |
| Click color swatch | Open popover with 5 palette swatches; selecting one updates `row.color` and closes popover. |
| Click `✕` | Remove that row from the array. No confirmation needed for individual rows. |
| Click `+ Add hours row` | Append a new row with `color: "navy"` and empty fields. Auto-focus the new row's Label input. |
| Drag a row's grip | Reorder; persist new order on drop. |
| Type in footnote | Update `schoolHours.footnote`; empty string = hide in PDF. |
| Close settings | All edits should already be persisted; no explicit save button needed (match existing pattern in the rest of the Settings panel). |

### PDF Render

- Reads `schoolHours.rows` and `schoolHours.footnote` directly.
- No interactivity — static.
- Render order matches the saved row order.
- Empty rows (no label AND no time) should be skipped silently.

### Empty states

- If `schoolHours.rows` is empty: render just the `SCHOOL HOURS` eyebrow and nothing else (or hide the panel entirely — match what makes sense for the calendar).
- If `schoolHours.footnote` is empty: hide the divider line and footnote text completely.

---

## State Management

Single store key: `schoolHours`. Shape defined above. Persist alongside the other school-info settings (school name, address, phone, etc.).

When the user opens Settings:
1. Read current `schoolHours` from storage.
2. If shape is the old freeform string, run the migration parser (see "Migration" above) to convert it to the new object before populating the editor. Save the migrated object back so subsequent loads skip the parse.
3. Hydrate the editor.

When the PDF is generated:
1. Read `schoolHours` (always the new object shape).
2. Pass to the PDF renderer which produces the layout described in Screen 2.

---

## Assets
No new image/icon assets are needed. The `★` is a Unicode character (`U+2605`). The `⋮⋮` drag grip and `✕` delete are also Unicode (`⋮` / `×`). Pill colors are CSS values, not images.

---

## Files in this Handoff

- `School Hours Box.html` — design reference. Open in a browser to inspect every variant on the design canvas.
  - The relevant sections are:
    - **"Settings Backend — Structured Input"** (top) — the editor design + live preview.
    - **"Refined — D & C, pushed further" → C2** — the final PDF layout (color pills).
  - Ignore variants A, B, D, D2, E, F unless cross-referencing.
- `screenshots/`
  - `01-pdf-card-final.png` — the new School Information card as it should render in the Traditional & Classic landscape PDFs.
  - `02-settings-panel.png` — the new Settings panel hours editor (rows + add button + footnote field).

---

## Implementation Order (suggested)

1. Add the `SchoolHours` types and the default seed.
2. Write the migration parser; test against the user's current freeform string.
3. Build the hours editor component (rows + add button + DnD + color popover).
4. Wire the footnote input.
5. Persist + hydrate from storage.
6. Update the PDF renderer's School Information card: replace the hours block with the pill-based layout.
7. QA with 5 rows, 8 rows, 2 rows, and 0 rows to confirm the box doesn't overflow.
